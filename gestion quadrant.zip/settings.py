from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    QDRANT_HOST: str
    QDRANT_PORT: int
    QDRANT_API_KEY: str
    QDRANT_HTTPS: bool

    DEFAULT_VECTOR_SIZE: int
    DEFAULT_DISTANCE: str

    @property
    def PROTOCOL(self) -> str:
        return "https" if self.QDRANT_HTTPS else "http"


settings = Settings()
