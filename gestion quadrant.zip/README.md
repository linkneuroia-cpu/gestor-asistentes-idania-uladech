Gestion Qdrant
